<?php $__env->startSection('content'); ?>

<div class="p-3 text-primary text-center">
        <h1><strong>Struktur Organisasi</strong></h1>
</div>
<img src="img/struktur.png" class="w3-image w3-greyscale-min rounded mx-auto d-block mt-5 mb-5" style="width:60%">

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipbp_user\resources\views/struktur.blade.php ENDPATH**/ ?>