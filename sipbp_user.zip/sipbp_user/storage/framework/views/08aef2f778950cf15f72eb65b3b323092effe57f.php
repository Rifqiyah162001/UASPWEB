<?php $__env->startSection('content'); ?>


<div class="container mt-3 mb-3 text-primary text-center">
    <h3><strong>SEJARAH</strong></h3>
</div>
<div class="container mt-5 text-dark text-center">
    <p>SMA N 13 Kota Jambi adalah salah satu satuan pendidikan dengan jenjang SMA di Talang Bakung, Kec. Paal Merah, Kota Jambi, Jambi. Dalam menjalankan kegiatannya, SMAN 13 KOTA JAMBI berada di bawah naungan Kementerian Pendidikan dan Kebudayaan. SMA N 13 Kota Jambi beralamat di Jln. Sersan Udara Syawal Rt.03 No.104 Talang Bakung, Talang Bakung, Kec. Paal Merah, Kota Jambi, Jambi, dengan kode pos 36139.</p>
    <p>Pembelajaran di SMA N 13 Kota Jambi dilakukan pada Double Shift. Dalam seminggu, pembelajaran dilakukan selama 6 hari. SMA N 13 Kota Jambi memiliki akreditasi C, berdasarkan sertifikat 1011/BAN-SM/SK/2019.</p>
    <table class="table">
        <tbody>
            <tr>
                <th scope="row">1</th>
                <td>NPSN</td>
                <td>69981036</td>
            </tr>
            <tr>
                <th scope="row">2</th>
                <td>Status</td>
                <td>Negeri</td>
            </tr>
            <tr>
                <th scope="row">3</th>
                <td>Bentuk Pendidikan</td>
                <td>SMA</td>
            </tr>
            <tr>
                <th scope="row">4</th>
                <td>Status Kepemilikan</td>
                <td>Pemerintah Daerah</td>
            </tr>
            <tr>
                <th scope="row">5</th>
                <td>SK Pendirian Sekolah</td>
                <td>KPTS.1790.A/DISDIK-2.2/VI/2018</td>
            </tr>
            <tr>
                <th scope="row">6</th>
                <td>Tanggal SK Pendirian</td>
                <td>2018-06-05</td>
            </tr>
            <tr>
                <th scope="row">7</th>
                <td>SK Izin Operasional</td>
                <td>KPTS.673/DISDIK-1.1/VIII/2018</td>
            </tr>
            <tr>
                <th scope="row">8</th>
                <td>Tanggal SK Izin Operasional</td>
                <td>2018-08-27</td>
            </tr>
        </tbody>
    </table>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipbp_user\resources\views/sejarah.blade.php ENDPATH**/ ?>