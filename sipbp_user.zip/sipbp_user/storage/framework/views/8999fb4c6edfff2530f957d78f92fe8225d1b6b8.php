<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(__('SIP2BP')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <img src="img/header.png" class="w3-image w3-greyscale-min" style="width:100%">
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-primary text-sm text-white-700  ">
            <div class="container">
                <ul class="navbar-nav ">
                    <li class="nav-item">
                        <a class="nav-link" href="/home">Beranda</a>
                    </li>
                </ul>
            <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">Profil</a>
                            <ul class="dropdown-menu dropdown-menu-white" aria-labelledby="navbarDarkDropdownMenuLink">
                                <li><a class="dropdown-item" href="/sejarah">Sejarah</a></li>
                                <li><a class="dropdown-item" href="/visimisi">Visi Misi</a></li>
                                <li><a class="dropdown-item" href="/struktur">Struktur Organisasi</a></li>
                                <li><a class="dropdown-item" href="/fasilitas">Fasilitas</a></li>
                            </ul>
                    </li>
                    <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
                        <ul class="navbar-nav">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">Perpustakaan</a>
                                    <ul class="dropdown-menu dropdown-menu-white" aria-labelledby="navbarDarkDropdownMenuLink">
                                        <li><a class="dropdown-item" href="/layanan">Pelayanan</a></li>
                                    </ul>
                            </li>
                        </ul>

                <!-- nav> -->

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <li class="nav-item">
                    <a class="nav-link" href="/kontakkami">Kontak Kami</a>
                </li>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                            <?php if(Auth::guest()): ?>
                                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a></li>
                                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a></li>
                            <?php else: ?>

                                <li class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown" role="button" aria-expanded="false">
                                        <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                    </a>

                                    <ul class="dropdown-menu" role="menu">
                                        <li>
                                            <a href="<?php echo e(route('logout')); ?>" class="text-dark btn"
                                                onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">
                                                Logout
                                            </a>
                                        </li>
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </ul>
                                </li>
                            <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <div class="container-fluid mt-5 p-1 bg-light text-blue text-center">
            <br></br>
            <h3><strong>Tentang Kami</strong></h3>
            <br></br>
            <div class="row">
                <div class="col-4">
                <div class="icon"><i class="fas fa-solid fa-users" style="font-size:48px"></i></div>
                    <h4>Institusi & Pustakawan</h4>
                    SMAN 13 KOTA JAMBI
                </div>
                <div class="col-4">
                    <div class="icon"><i class="fas fa-regular fa-envelope" style="font-size:48px"></i></div>
                        <h4>Kontak Kami</h4>
                        Jl. Sersan Udara Syawal
                        Talang Bakung, Jambi 36127
                        <br>@sman13kotaJambi.gmail.com</br>
                    </div>
                <div class="col-4">
                    <div class="icon"><i class="fas fa-solid fa-calendar-day" style="font-size:48px"></i></div>
                        <h4>Jam Operasional</h4>
                        Senin-Jumat 08.00 - 16.00 WIB
                    </div>
                    <br>
                </div>

                </br>
            </div>
        </div>

        <div class="container-fluid p-1 bg-primary text-white text-center">
            <p>Hak Cipta 2022 © Perpustakaan SMAN 13 kota Jambi. Seluruhnya dilindungi Hak Cipta.</p>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\sipbp_user\resources\views/layouts/main.blade.php ENDPATH**/ ?>