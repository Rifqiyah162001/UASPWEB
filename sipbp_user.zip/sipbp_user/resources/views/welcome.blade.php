@extends('layouts.main')
@section('content')

        <br>
        <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
        <!-- Indicators -->
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>

        <!-- Sliddes Photo -->
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="img/10.jpg" class="d-block w-50 mx-auto d-block" alt="...">
            </div>
            <div class="carousel-item">
                <img src="img/11.jpg" class="d-block w-50 mx-auto d-block" alt="...">
            </div>
            <div class="carousel-item">
                <img src="img/13.jpg" class="d-block w-50 mx-auto d-block" alt="...">
            </div>
        </div>

        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>

    <!-- Container (Berita Section) -->
    <div id="portfolio" class="container-fluid text-center bg-grey">
        <h2></h2><br>
        <h4></h4>
        <div class="container">
            <h3><strong>Artikel Terkini</strong></h3>
            <br></br>
        <div class="row text-center slideanim">
        <div class="col-sm-4">
            <div class="thumbnail">
                <img src="img/4.jpg"  style="width:50%">
                <a class="nav-link active" href="https://metrojambi.com/read/2018/09/27/35590/baru-berdiri-sma-13-jambi-telah-lahirkan-prestasi">Baru Berdiri,
                <br>SMA 13 Jambi Telah Lahirkan Prestasi</br></a>
                <p><strong>JAMBI - </strong> SMA Negeri 13 Kota Jambi yang baru beroperasi pada tahun ajaran baru ini atau tepatnya baru berusia 3 bulan ini telah melahirkan prestasi dalam bidang non akademik, yakni Putra Putri Jambi (PPJ) 2017 dan tinju tingkat nasional... </p>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="thumbnail">
                <img src="img/5.jpg" style="width:50%">
                <a class="nav-link active" href="https://wartanews.co/sma-negeri-13-kota-jambi-menerima-260-peserta-didik-baru/">SMA Negeri 13 Kota Jambi
                <br>Menerima 260 Peserta Didik Baru</br></a>
                <p><strong>JAMBI (WARTANEWS.CO) – </strong> kegiatan belajar mengajar ratusan orang siswa/siswi berlangsung di salah satu Sekolah Menengah Atas (SMA) berstatus negeri milik pemerintah daerah (pemda) Provinsi Jambi, yang baru saja dibuka oleh Dinas...</p>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="thumbnail">
                <img src="img/6.jpg"  style="width:50%">
                <a class="nav-link active" href="https://wartanews.co/siswa-dan-siswi-sman-13-kota-jambi-wajib-pramuka/">Siswa dan Siswi SMAN 13,
                <br>Kota Jambi Wajib Pramuka</br></a>
                <p><strong> JAMBI (WARTANEWS.CO) – </strong> Pembentukan karakter bagi peserta didik menjadi program prioritas di lingkungan Sekolah Menengah Atas (SMA) Negeri 13 Kota Jambi, yang baru pertama kali berdiri dan mulai dioperasionalkan pada Tahun... </p>
            </div>
        </div>
    </div>
@endsection



