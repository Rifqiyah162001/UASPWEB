@extends('layouts.main')
@section('content')

<div class="p-3 text-primary text-center">
        <h1><strong>Struktur Organisasi</strong></h1>
</div>
<img src="img/struktur.png" class="w3-image w3-greyscale-min rounded mx-auto d-block mt-5 mb-5" style="width:60%">

@endsection
