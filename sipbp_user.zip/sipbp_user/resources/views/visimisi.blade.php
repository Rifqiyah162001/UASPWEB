@extends('layouts.main')
@section('content')

<div class="container mt-3 mb-3 text-primary text-center">
    <h3><strong>VISI</strong></h3>
</div>
<div class="container mt-5 text-dark text-center">
    <p>Mewujudkan Sumber Daya Manusia (SDM) yang cerdas, unggul, kompetitif, berkarakter, dan berbudaya lingkungan.</p>
    <br>
    <div class="container mt-3 mb-3 text-primary text-center">
        <h3><strong>MISI</strong></h3>
    </div>
    <div class="container mt-5 text-dark text-center">
        <p>Untuk mewujudkan visi tersebut, maka pihak sekolah melaksanakan delapan misi untuk mencapainya, yaitu meningkatkan pembinaan akhlak dan budi pekerti yang luhur; mengembangkan pembinaan minat, bakat dan kreatifitas peserta didik agar tumbuh dan berkembang sesuai dengan potensi yang dimiliki peserta didik; meningkatkan profesionalisme tenaga pendidik dan kependidikan melalui kegiatan In House Training (IHT) dan Musyawarah Guru Mata Pelajaran (MGMP).</p>
        <p>Meningkatkan kualitas Kegiatan Belajar Mengajar (KBM) melalui pengembangan multimedia yang dapat memotivasi peserta didik untuk kreatif, inisiatif dan inovatif baik dalam kegiatan intra maupun ekstra kurikuler; mampu bersaing secara akademik melalui peningkatan KBM, les tambahan dan pengembangan diri; meningkatkan insfrastruktur yang mendukung pelaksanaan program sekolah; menjalin kerjasama dengan mitra kerja dan alumni; serta menciptakan lingkungan kerja yang religius, kondusif, bersih dan ASRI (Aman, Sejuk, Rindang, dan Indah).</p>
    </div>
</div>

@endsection
