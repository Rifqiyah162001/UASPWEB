@extends('layouts.app')
@section('content')

<div class="container mt-3 mb-3 text-primary text-center">
        <h1>Kontak Kami</h1>
</div>

<!--gambar maps-->
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.2054265553643!2d103.6407749139477!3d-1.6292156988119482!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e25856c52efe933%3A0xb0ba04372c0bb64a!2sSMA%20Negeri%2013%20Kota%20Jambi!5e0!3m2!1sen!2sid!4v1654413323445!5m2!1sen!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" class="rounded mx-auto d-block mb-5"></iframe>

@endsection
