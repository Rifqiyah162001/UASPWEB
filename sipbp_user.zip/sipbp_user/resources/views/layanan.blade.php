@extends('layouts.main')
@section('content')

<div class="p-3 text-primary text-center">
        <h1><strong>Layanan</strong></h1>
</div>
<div class="row text-center slideanim">
    <div class="col-sm-4">
        <div class="thumbnail">
            <img src="img/12.jpeg"  style="width:70%">
            <p><br><strong>Layanan Referensi</strong></br><p>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="thumbnail">
            <img src="img/14.jpeg"  style="width:70%">
            <p><br><strong>Layanan Sirkulasi</strong></br><p>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="thumbnail">
            <img src="img/15.jpeg"  style="width:70%">
            <p><br><strong>Layanan Penelusuran Informasi</strong></br><p>
        </div>
    </div>

@endsection
