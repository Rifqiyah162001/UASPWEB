@extends('layouts.main')

@section('content')
<div class="p-3 bg-primary text-white text-center">
    <h1>Aturan Peminjaman Buku</h1>
</div>

<div class="container text-left mt-5">
<ul class="list-unstyled">
    <li><strong>Persyaratan : </strong>
        <ul>
            <li>Minimal berusia 14 tahun</li>
            <li>Warga Negara Indonesia</li>
            <li>Menyertakan fotocopy Kartu Tanda Pengenal (Kartu Pelajar) kepada petugas</li>
        </ul>
    </li>
    <br>
    <li><strong>Tata Tertib : </strong>
        <ul>
            <li>Kartu pelajar harus dibawa setiap kali berkunjung</li>
            <li>Kartu pelajar tidak boleh dipinjamkan kepada orang lain</li>
            <li>Peminjaman buku maksimal 2</li>
            <li>Lama peminjaman buku 1 minggu dari tanggal peminjaman</li>
            <li>Terlambat mengembalikan, dikenakan sanksi sesuai kebijakan Perpustakaan</li>
            <li>Wajib mengganti bahan pustaka yang rusak, tertukar dan hilang dengan judul yang sama</li>
        </ul>
    </li>
</ul>
<br>
</div>
@endsection
