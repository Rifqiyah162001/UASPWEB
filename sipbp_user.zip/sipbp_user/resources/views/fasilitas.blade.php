@extends('layouts.main')
@section('content')
<div class="container mt-3 mb-3 text-primary text-center">
        <h3><strong>FASILITAS</strong></h3>
</div>
<div class="container mt-5 text-dark text-center">
    <p>Fasilitas yang disediakan SMA N 13 Kota Jambi menyediakan listrik untuk membantu kegiatan belajar mengajar. Sumber listrik yang digunakan oleh SMAN 13 KOTA JAMBI berasal dari PLN. SMAN 13 KOTA JAMBI menyediakan akses internet yang dapat digunakan untuk mendukung kegiatan belajar mengajar menjadi lebih mudah. Provider yang digunakan SMAN 13 KOTA JAMBI untuk sambungan internetnya adalah Telkomsel Flash</p>
    <br>
</div>
@endsection
