@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="row container-fluid mt-3">
                    <div class="col-md-12" align="start" style="font-size: 1rem;">
                        <h3>Tambah Data Buku</h3>
                    </div>
                </div>
                <div class="card-body">
                    <form action="{{ route('book.update', $book->id) }}" class="form-horizontal" method="POST">  
                        {{ csrf_field() }}
                        <input type="hidden" name="_method" value="PUT">
                        <div class="mb-3 mt-3">
                            <label for="kode">Kode Buku:</label>
                            <input type="text" class="form-control" name="kode" value="{{ $book->kode_buku }}">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="NamaPeminjam">Nama Peminjam:</label>
                            <input type="text" class="form-control" name="NamaPeminjam" value="{{ $book->NamaPeminjam }}">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="Kelas">Kelas:</label>
                            <input type="text" class="form-control" name="Kelas" value="{{ $book->Kelas }}">
                        </div>
                        <div class="mb-3">
                            <label for="judul">Judul Buku:</label>
                            <input type="text" class="form-control" name="judul" value="{{ $book->judul_buku }}">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="pengarang">Pengarang:</label>
                            <input type="text" class="form-control" name="pengarang" value="{{ $book->pengarang }}">
                        </div>
                        <div class="mb-3">
                            <label for="penerbit">Penerbit:</label>
                            <input type="text" class="form-control" name="penerbit" value="{{ $book->penerbit }}">
                        </div>
						<div class="mb-3 mt-3">
                            <label for="tahunterbit">Tahun Terbit:</label>
                            <input type="text" class="form-control" name="tahunterbit" value="{{ $book->tahun_terbit }}">
                        </div>
						<div class="form-group">
							<div class="col-sm-offset-2 col-sm-10">
								<button type="submit" class="btn btn-primary">Simpan</button>
							</div>
						</div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection