@extends('layouts.app')	
@section('content')
<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-head container-fluid" style="margin-top: 10px;">
					<div class="pull-right" style="text-align">
						<h1>Data Buku</h1>
                        <br>
					</div>
					<a href="{{ route('book.create') }}" class="btn btn-primary">Tambah Buku</a>
				</div>
                <br>
				<div class="panel-body text-center">
					<table class="table table-hover">
						<thead>
							<tr>
                                <th>id</th>
								<th>Kode Buku</th>
                                <th>Nama Peminjam</th>
                                <th>Kelas</th>
								<th>Judul Buku</th>
								<th>Pengarang</th>
								<th>Penerbit</th>
								<th>Tahun Terbit</th>
								<th>Dibuat pada</th>
								<th>Diedit pada</th>
								<th colspan="3" style="text-align: center;">Aksi</th>
							</tr>
						</thead>
						<tbody>
							@foreach ( $book as $i => $b)
							<tr>
								<td>{{ $i+1 }}</td>
								<td>{{ $b->kode_buku }}</td>
                                <td>{{ $b->NamaPeminjam }}</td>
                                <td>{{ $b->Kelas }}</td>
								<td>{{ $b->judul_buku }}</td>
								<td>{{ $b->pengarang }}</td>
								<td>{{ $b->penerbit }}</td>
                                <td>{{ $b->tahun_terbit }}</td>
								<td>{{ $b->created_at }}</td>
								<td>{{ $b->updated_at }}</td>
								<td><a href="{{ route('book.show',$b->id) }}" class="btn btn-warning"> Detail</a></td>
								<td><a class="btn btn-success" href="{{ route('book.edit',$b->id) }}"> Edit</a></td>
								<td>
									<form method="post" action="{{ route('book.destroy',$b->id) }}"> {{ csrf_field() }} 
										<input type="hidden" name="_method" value="DELETE">
										<button class="btn btn-danger" type="submit">Hapus</button>
									</form>
								</td>
							</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection
