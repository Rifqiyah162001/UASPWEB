@extends('layouts.app')
@section('content')
<div class="container">
	<div class="row">
		<div class="com-md-12">
			<div class="card">
				<div class="row container-fluid" style="margin-top: 10px;">
					<h3>Tambah Data Buku</h3>
				</div>
				<div class="card-body">
					<form class="form-horizontal" action="{{ route('book.store') }}" method="post"> {{ csrf_field() }}
                        <div class="mb-3 mt-3">
                            <label for="kode">Kode Buku:</label>
                            <input type="kode" class="form-control" id="kode" placeholder="Enter Kode Buku" name="kode">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="kode">Nama Peminjam:</label>
                            <input type="NamaPeminjam" class="form-control" id="NamaPeminjam" placeholder="Enter Nama Peminjam" name="NamaPeminjam">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="kode">Kelas:</label>
                            <input type="Kelas" class="form-control" id="kelas" placeholder="Enter Kelas" name="Kelas">
                        </div>
                        <div class="mb-3">
                            <label for="judul">Judul Buku:</label>
                            <input type="judul" class="form-control" id="judul" placeholder="Enter Judul Buku" name="judul">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="pengarang">Pengarang:</label>
                            <input type="pengarang" class="form-control" id="pengarang" placeholder="Enter Pengarang" name="pengarang">
                        </div>
                        <div class="mb-3">
                            <label for="penerbit">Penerbit:</label>
                            <input type="penerbit" class="form-control" id="penerbit" placeholder="Enter Penerbit" name="penerbit">
                        </div>
						<div class="mb-3 mt-3">
                            <label for="tahunterbit">Tahun Terbit:</label>
                            <input type="tahunterbit" class="form-control" id="tahunterbit" placeholder="Enter Tahun Terbit" name="tahunterbit">
                        </div>
                        <div class="form-group">
							<div class="col-sm-offset-2 col-sm-10">
								<button type="submit" class="btn btn-primary">Simpan</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection