	
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-head container-fluid" style="margin-top: 10px;">
					<div class="pull-right" style="text-align">
						<h1>Data Buku</h1>
                        <br>
					</div>
					<a href="<?php echo e(route('book.create')); ?>" class="btn btn-primary">Tambah Buku</a>
				</div>
                <br>
				<div class="panel-body text-center">
					<table class="table table-hover">
						<thead>
							<tr>
                                <th>id</th>
								<th>Kode Buku</th>
                                <th>Nama Peminjam</th>
                                <th>Kelas</th>
								<th>Judul Buku</th>
								<th>Pengarang</th>
								<th>Penerbit</th>
								<th>Tahun Terbit</th>
								<th>Dibuat pada</th>
								<th>Diedit pada</th>
								<th colspan="3" style="text-align: center;">Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($i+1); ?></td>
								<td><?php echo e($b->kode_buku); ?></td>
                                <td><?php echo e($b->NamaPeminjam); ?></td>
                                <td><?php echo e($b->Kelas); ?></td>
								<td><?php echo e($b->judul_buku); ?></td>
								<td><?php echo e($b->pengarang); ?></td>
								<td><?php echo e($b->penerbit); ?></td>
                                <td><?php echo e($b->tahun_terbit); ?></td>
								<td><?php echo e($b->created_at); ?></td>
								<td><?php echo e($b->updated_at); ?></td>
								<td><a href="<?php echo e(route('book.show',$b->id)); ?>" class="btn btn-warning"> Detail</a></td>
								<td><a class="btn btn-success" href="<?php echo e(route('book.edit',$b->id)); ?>"> Edit</a></td>
								<td>
									<form method="post" action="<?php echo e(route('book.destroy',$b->id)); ?>"> <?php echo e(csrf_field()); ?> 
										<input type="hidden" name="_method" value="DELETE">
										<button class="btn btn-danger" type="submit">Hapus</button>
									</form>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\web_sipbp\resources\views/book/index.blade.php ENDPATH**/ ?>