
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="row container-fluid mt-3">
                    <div class="col-md-12" align="start" style="font-size: 1rem;">
                        <h3>Data Detail Buku</h3>
                    </div>
                </div>
                <div class="card-body">
                    <div class="form-horizontal">  
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="PUT">
                        <div class="form-group">
                            <label class="control-label col-sm-2">id</label>
                            <div class="col-sm-12">
                                <p>"<?php echo e($book->id); ?>"</p> 
                            </div>
                        </div><br>
                        <div class="form-group">
                            <label class="control-label col-sm-2">Kode Buku</label>
                            <div class="col-sm-12">
                                <p><?php echo e($book->kode_buku); ?></p>
                            </div>
                        </div><br>
                        <div class="form-group">
                            <label class="control-label col-sm-2">Nama Peminjam</label>
                            <div class="col-sm-12">
                                <p><?php echo e($book->NamaPeminjam); ?></p>
                            </div>
                        </div><br>
                        <div class="form-group">
                            <label class="control-label col-sm-2">Kelas</label>
                            <div class="col-sm-12">
                                <p><?php echo e($book->Kelas); ?></p>
                            </div>
                        </div><br>
                        <div class="form-group">
                            <label class="control-label col-sm-2">Nama Peminjam</label>
                            <div class="col-sm-12">
                                <p><?php echo e($book->NamaPeminjam); ?></p>
                            </div>
                        </div><br>
                        <div class="form-group">
                            <label class="control-label col-sm-2">Kelas</label>
                            <div class="col-sm-12">
                                <p><?php echo e($book->Kelas); ?></p>
                            </div>
                        </div><br>
                        <div class="form-group">
                            <label class="control-label col-sm-2">Judul Buku</label>
                            <div class="col-sm-12">
                                <p><?php echo e($book->judul_buku); ?></p>
                            </div>
                        </div><br>
                        <div class="form-group">
                            <label class="control-label col-sm-2">Pengarang</label>
                            <div class="col-sm-12">
                                <p><?php echo e($book->pengarang); ?></p>
                            </div>
                        </div><br>
                        <div class="form-group">
                            <label class="control-label col-sm-2">Penerbit</label>
                            <div class="col-sm-12">
                                <p><?php echo e($book->penerbit); ?></p>
                            </div>
                        </div><br>
                        <div class="form-group">
                            <label class="control-label col-sm-2">Tahun Terbit</label>
                            <div class="col-sm-12">
                                <p><?php echo e($book->tahun_terbit); ?></p>
                            </div>
                        </div><br>
                        <div class="form-group">
                            <div class="col-sm-offset-2 col-sm-12">
                                <button onclick="location.href='<?php echo e(url('book')); ?>'" class="btn btn-warning">Data Buku</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\web_sipbp\resources\views/book/show.blade.php ENDPATH**/ ?>